"""
File: upload_to_esm.py
Author: Jaden Mounteer
Purpose: This program aids in the Upload to ESM process.
It reads a sql query, writes it to a .csv file, and formats
the data correctly. It then opens the ESM website.
"""

# Imports the pandas library to work with datasets and csv files.
# Remember to install this library by typing pip3 install pandas into 
# the terminal.
import pandas as pd
import xlrd
import openpyxl
import yaml
from sqlalchemy import create_engine
import urllib
# Also install pyodbc in pip
# Also intall sqlalchemy using pip
# Imports the webbrowser library so we can navigate to websites
import webbrowser
import datetime # So we can work with the date and the time.
import shutil # used to move files.

def find_time_and_day():
    """
    Finds the time.
    :return: the time of day.
    """
    # Finds the time and day
    print("Figuring out what day it is...")
    now = datetime.datetime.now()
    date = now.strftime("%x")
    # Removes the special characters from the date and replaces them with dashes.
    reformated_date = date.replace("/", "-")
    military_time = now.strftime("%X")
    # Take the special characters out of the time
    reformated_time = military_time.replace(":", ".")
    time_and_date = reformated_date + " " + reformated_time
    return time_and_date

def main():
    """
    Opens the sql query.
    Writes it to a .csv file.
    Formats the file correctly.
    :return: None
    """
    print("UPLOAD TO ESM")
    print("")

    # opens the SQL query.
    print("Opening SQL query...")
    with open(r'src/sql_query.yml') as file:
        config = yaml.load(file, Loader=yaml.FullLoader)
 
    params = urllib.parse.quote_plus("DRIVER={SQL Server};"
                 "SERVER=gp-server;"
                 "DATABASE=[Name of database];"
                 "Trusted_Connection=yes;")
    engine = create_engine("mssql+pyodbc:///?odbc_connect=%s" % params) 

    # Reads the sql query into the df variable.
    print("Reading SQL query...") 
    df = pd.read_sql(con=engine, sql = config["sql"])

    # Counts the number of orders.
    number_of_orders = len(df)

    # If there are no orders in the dataframe.
    if number_of_orders <= 0:
        #Prints a message to the user.
        print("WARNING: There are no orders.")
        print("Please make sure the orders you need are in")
        print("the correct queue in SalesPad.")
        input("Press ENTER to close program.")
    
    # Or, if there are orders
    else: 
        
        # Configures the .csv filename
        time_and_day = find_time_and_day()
        csv_filename = "upload to ESM " + time_and_day + ".csv"

        # Writes the dataframe to a csv file with today's date and time.
        print("Writing to csv file...")
        df.to_csv(csv_filename, index=False, index_label=False)
        print("Created file: " + csv_filename + ".")

        # prints the number of orders.
        print("There are " + str(number_of_orders) + " orders to be uploaded.")

        # Opens the website.
        print("Opening ESM's Website...")
        webbrowser.open("https://esm.deposco.com/deposco/login/home?returnUrl=%2F")
        print("")

        # Moves the uploaded file to the history folder
        response = False
        while response != "":
            print("Has the file been uploaded?")
            response = input("Press ENTER to move file to history folder and close program: ")
        
        print("File moved to history folder.")
        shutil.move(csv_filename, 'history/' + csv_filename)
    




        

     

    
# Runs the main() function.
if __name__ == "__main__":
    main()


