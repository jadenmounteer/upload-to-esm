This program aids in the Upload to ESM process.
It reads a sql query, writes it to a .csv file, and formats
the data correctly. It then opens the ESM website and moves the file
to the history folder.

To run the program, double click on the upload_to_esm.exe file.